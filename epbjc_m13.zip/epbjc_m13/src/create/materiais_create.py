import sqlite3

conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()

for i in range (1,21):
    cursor.execute('INSERT INTO material (marca, cor) VALUES ("Note", "Preto")')
 
conexao.commit()
conexao.close()