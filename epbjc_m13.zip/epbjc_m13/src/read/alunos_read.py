import sqlite3
 
conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()
 
cursor.execute('SELECT * FROM alunos')
 
resultados = cursor.fetchall()
 
for aluno in resultados:
    print(aluno)
 
 
conexao.close()