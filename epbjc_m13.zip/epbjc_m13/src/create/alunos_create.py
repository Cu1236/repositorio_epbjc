import sqlite3
import random

 
conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()
 
primeiros_nomes = ["Ximão","Joel","Alexis","Iuri","David","Pedro","Soraia","Ander"]
ultimo_nome = ["Parreirinha","Ferreira","Matoso","Gonçalves","Santos","Moretti","Novas","Bogalho"]


for i in range (1,21):
    nome_gerado = f"{random.choice(primeiros_nomes)} {random.choice(ultimo_nome)}"
    idade_aleatoria = random.randint(15,19)
    cursor.execute('INSERT INTO alunos (nome, idade) VALUES(?, ?)', (nome_gerado, idade_aleatoria))
 
conexao.commit()
conexao.close()