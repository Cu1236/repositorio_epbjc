import sqlite3
 
 
conexao = sqlite3.connect('epbjc.db')
cursor = conexao.cursor()
 
cursor.execute('SELECT * FROM material')
 
resultados = cursor.fetchall()
 
for material in resultados:
    print(material)
 
 
conexao.close()